<footer class="container-fluid text-center" id="footer">
  <p>&copy; Copyright 2019 all rights reserved.</p>
</footer>

</body>
</html>